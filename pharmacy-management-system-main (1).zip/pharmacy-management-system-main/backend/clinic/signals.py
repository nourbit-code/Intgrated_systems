from django.db.models.signals import post_save
from django.dispatch import receiver

from clinic.models import Prescription
from pharmacy.models import PharmacyOrder


@receiver(post_save, sender=Prescription)
def create_pharmacy_order(sender, instance, created, **kwargs):
    if not created:
        return
    PharmacyOrder.objects.get_or_create(
        prescription=instance,
        defaults={
            'patient': instance.patient,
            'status': 'New',
        },
    )
