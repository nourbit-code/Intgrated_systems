from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from clinic.fhir import (
    extract_medication_requests,
    import_medication_request,
    order_to_medication_dispense,
    patient_to_fhir,
    practitioner_to_fhir,
    prescription_to_medication_request,
    resources_to_bundle,
)
from clinic.models import Prescription
from pharmacy.models import PharmacyOrder


class FhirMedicationRequestImportView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        try:
            medication_requests, resources_by_ref = extract_medication_requests(request.data)
        except ValueError as exc:
            return Response(
                {
                    'resourceType': 'OperationOutcome',
                    'issue': [{'severity': 'error', 'code': 'invalid', 'diagnostics': str(exc)}],
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        imported = []
        created_any = False
        for medication_request in medication_requests:
            prescription, order, created = import_medication_request(medication_request, resources_by_ref)
            created_any = created_any or created
            imported.append(
                {
                    'resourceType': 'Bundle',
                    'type': 'collection',
                    'entry': [
                        {'resource': prescription_to_medication_request(prescription)},
                        {'resource': patient_to_fhir(prescription.patient)},
                        {'resource': practitioner_to_fhir(prescription.doctor)},
                        {'resource': order_to_medication_dispense(order)},
                    ],
                }
            )

        response_status = status.HTTP_201_CREATED if created_any else status.HTTP_200_OK
        if len(imported) == 1:
            return Response(imported[0], status=response_status)
        return Response(resources_to_bundle(imported), status=response_status)


class FhirMedicationRequestListView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        prescriptions = Prescription.objects.select_related('patient', 'doctor').order_by('-created_at')
        resources = [prescription_to_medication_request(prescription) for prescription in prescriptions]
        return Response(resources_to_bundle(resources))


class FhirMedicationRequestDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        prescription = Prescription.objects.select_related('patient', 'doctor').filter(pk=pk).first()
        if prescription is None:
            return Response(
                {
                    'resourceType': 'OperationOutcome',
                    'issue': [{'severity': 'error', 'code': 'not-found', 'diagnostics': 'MedicationRequest not found.'}],
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        return Response(prescription_to_medication_request(prescription))


class FhirMedicationDispenseListView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        orders = PharmacyOrder.objects.select_related('patient', 'prescription').prefetch_related('items').order_by(
            '-created_at'
        )
        prescription_id = request.query_params.get('prescription')
        if prescription_id:
            orders = orders.filter(prescription_id=prescription_id)
        resources = [order_to_medication_dispense(order) for order in orders]
        return Response(resources_to_bundle(resources))


class FhirMedicationDispenseDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        order = (
            PharmacyOrder.objects.select_related('patient', 'prescription')
            .prefetch_related('items')
            .filter(pk=pk)
            .first()
        )
        if order is None:
            return Response(
                {
                    'resourceType': 'OperationOutcome',
                    'issue': [{'severity': 'error', 'code': 'not-found', 'diagnostics': 'MedicationDispense not found.'}],
                },
                status=status.HTTP_404_NOT_FOUND,
            )
        return Response(order_to_medication_dispense(order))
